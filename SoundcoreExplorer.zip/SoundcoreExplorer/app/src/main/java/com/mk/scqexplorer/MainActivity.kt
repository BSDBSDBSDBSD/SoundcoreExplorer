package com.mk.scqexplorer

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.*
import kotlin.concurrent.thread

/**
 * Soundcore Protocol Explorer
 * -----------------------------------------
 * כלי לחקירת הפרוטוקול של אוזניות/רמקולי Soundcore (Anker).
 * מתחבר למכשיר מותאם (paired) דרך SPP/RFCOMM — אותו ערוץ שבו
 * אפליקציית Soundcore מדברת עם האוזניות — ומאפשר לשלוח פקודות גולמיות
 * ולראות את התשובות בהקס. כך אפשר למפות אילו פקודות השבב מכיר.
 *
 * שים לב: הכלי קורא/שולח פקודות בלבד. הוא אינו משנה קושחה ואינו "צורב".
 */
class MainActivity : ComponentActivity() {

    // UUID סטנדרטי של SPP. חלק מדגמי Soundcore משתמשים בו; אם לא מתחבר,
    // אפשר להחליף ל-UUID שמופיע ב-fetchUuids() (מודפס ללוג בבחירת מכשיר).
    private var sppUuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    private val adapter: BluetoothAdapter? by lazy {
        (getSystemService(BLUETOOTH_SERVICE) as android.bluetooth.BluetoothManager).adapter
    }

    private var socket: BluetoothSocket? = null
    private var selectedDevice: BluetoothDevice? = null

    private lateinit var log: TextView
    private lateinit var cmdInput: EditText
    private lateinit var uuidInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestPerms()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }

        val pickBtn = Button(this).apply { text = "בחר מכשיר Soundcore מותאם" }
        val connectBtn = Button(this).apply { text = "התחבר (SPP)" }
        val probeBtn = Button(this).apply { text = "שלח פקודת מצב/מידע נפוצה" }

        uuidInput = EditText(this).apply {
            hint = "UUID (ברירת מחדל: SPP). החלף אם צריך"
            setText(sppUuid.toString())
        }
        cmdInput = EditText(this).apply {
            hint = "פקודה בהקס, למשל: 08 EE 00 00 00 01 01"
        }
        val sendBtn = Button(this).apply { text = "שלח פקודת הקס" }

        log = TextView(this).apply {
            text = "מוכן.\n"
            setTextIsSelectable(true)
            movementMethod = ScrollingMovementMethod()
            height = 900
        }

        root.addView(pickBtn)
        root.addView(uuidInput)
        root.addView(connectBtn)
        root.addView(probeBtn)
        root.addView(TextView(this).apply { text = "\nפקודה ידנית:" })
        root.addView(cmdInput)
        root.addView(sendBtn)
        root.addView(TextView(this).apply { text = "\nלוג:" })
        root.addView(log)
        setContentView(ScrollView(this).apply { addView(root) })

        pickBtn.setOnClickListener { pickDevice() }
        connectBtn.setOnClickListener { connect() }
        probeBtn.setOnClickListener { sendProbe() }
        sendBtn.setOnClickListener { sendHex(cmdInput.text.toString()) }
    }

    private fun requestPerms() {
        val perms = if (Build.VERSION.SDK_INT >= 31)
            arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
        else arrayOf(Manifest.permission.BLUETOOTH, Manifest.permission.BLUETOOTH_ADMIN)
        ActivityCompat.requestPermissions(this, perms, 1)
    }

    private fun hasConnect(): Boolean =
        Build.VERSION.SDK_INT < 31 ||
        ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) ==
            PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    private fun pickDevice() {
        if (!hasConnect()) { logln("אין הרשאת Bluetooth. אשר/י ונסה שוב."); return }
        val bonded = adapter?.bondedDevices?.toList().orEmpty()
        if (bonded.isEmpty()) { logln("אין מכשירים מותאמים. התאם/י את האוזניות בהגדרות קודם."); return }

        val names = bonded.map { "${it.name}  (${it.address})" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("מכשירים מותאמים")
            .setItems(names) { _, i ->
                selectedDevice = bonded[i]
                logln("נבחר: ${bonded[i].name} / ${bonded[i].address}")
                // הדפסת כל ה-UUIDs שהמכשיר מפרסם — עוזר לזהות את הערוץ הנכון
                bonded[i].uuids?.forEach { logln("  UUID: ${it.uuid}") }
            }.show()
    }

    @SuppressLint("MissingPermission")
    private fun connect() {
        val dev = selectedDevice ?: run { logln("בחר/י מכשיר קודם."); return }
        try { sppUuid = UUID.fromString(uuidInput.text.toString().trim()) }
        catch (e: Exception) { logln("UUID לא תקין, משתמש בברירת מחדל.") }

        thread {
            try {
                adapter?.cancelDiscovery()
                val s = dev.createRfcommSocketToServiceRecord(sppUuid)
                s.connect()
                socket = s
                logln("✓ מחובר דרך SPP ($sppUuid)")
                startReader(s)
            } catch (e: Exception) {
                logln("✗ חיבור נכשל: ${e.message}")
                logln("  נסה/י UUID אחר מהרשימה שהודפסה, או ודא/י שהאוזניות לא מחוברות לאפליקציית Soundcore במקביל.")
            }
        }
    }

    private fun startReader(s: BluetoothSocket) {
        thread {
            val buf = ByteArray(1024)
            try {
                val ins = s.inputStream
                while (true) {
                    val n = ins.read(buf)
                    if (n > 0) logln("← ${buf.copyOf(n).toHex()}")
                }
            } catch (e: Exception) { logln("קורא נסגר: ${e.message}") }
        }
    }

    /**
     * פקודת "בקשת מצב" נפוצה בפרוטוקול Soundcore.
     * מבנה כללי: [08 EE 00 00] [command bytes] [checksum].
     * זו נקודת פתיחה לחקירה — התשובה תחשוף את מבנה המסגרת האמיתי של הדגם שלך.
     */
    private fun sendProbe() {
        sendHex("08 EE 00 00 00 01 01")
    }

    private fun sendHex(raw: String) {
        val s = socket ?: run { logln("לא מחובר."); return }
        val bytes = try { raw.hexToBytes() }
        catch (e: Exception) { logln("הקס לא תקין."); return }
        thread {
            try {
                s.outputStream.write(bytes)
                s.outputStream.flush()
                logln("→ ${bytes.toHex()}")
            } catch (e: Exception) { logln("שליחה נכשלה: ${e.message}") }
        }
    }

    private fun logln(msg: String) = runOnUiThread {
        log.append(msg + "\n")
    }

    private fun ByteArray.toHex() = joinToString(" ") { "%02X".format(it) }
    private fun String.hexToBytes(): ByteArray =
        trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
            .map { it.toInt(16).toByte() }.toByteArray()
}
